# Go Lang Tutorials


##  Object Orientedness
Go lang is object oriented, but there is no `class` construct.  Instead use
`struct`.  Can't define methods within a `struct`, but you can associate them
with a stuct.
